# Copyright (c) 2019, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

import unittest


class TestChartofAccountsImporter(unittest.TestCase):
	pass
