Master for modes of payment.

e.g.

- Cash
- Credit Card
- Bank Transfer
- Check